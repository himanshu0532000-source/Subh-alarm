package com.subah.alarm
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.util.Calendar

object Scheduler {
    private fun pi(c: Context, step: Int) = PendingIntent.getBroadcast(c, step,
        Intent(c, AlarmReceiver::class.java).putExtra("step", step), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    fun setStep(c: Context, step: Int, at: Long) {
        Store.p(c).edit().putLong("pat_$step", at).apply()
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val show = PendingIntent.getActivity(c, 100, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        am.setAlarmClock(AlarmManager.AlarmClockInfo(at, show), pi(c, step))
    }
    fun cancel(c: Context, step: Int) {
        (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi(c, step))
        Store.p(c).edit().remove("pat_$step").apply()
    }
    /** Agle enabled din ka pehla alarm set karta hai. -1 agar koi din on nahi. */
    fun scheduleNext(c: Context): Long {
        val days = Store.days(c); val now = System.currentTimeMillis()
        for (k in 0..7) {
            val d = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, k) }
            val cfg = days[d.get(Calendar.DAY_OF_WEEK) - 1]
            if (!cfg.on) continue
            d.set(Calendar.HOUR_OF_DAY, cfg.h); d.set(Calendar.MINUTE, cfg.m); d.set(Calendar.SECOND, 0); d.set(Calendar.MILLISECOND, 0)
            if (d.timeInMillis > now + 1000) { setStep(c, 0, d.timeInMillis); return d.timeInMillis }
        }
        cancel(c, 0); return -1
    }
    /** Reboot ke baad saare pending alarms wapas lagata hai. */
    fun restore(c: Context) {
        val n = System.currentTimeMillis()
        for (s in 1..9) { val at = Store.p(c).getLong("pat_$s", 0); if (at > n) setStep(c, s, at) }
        val a0 = Store.p(c).getLong("pat_0", 0)
        if (a0 > n) setStep(c, 0, a0) else scheduleNext(c)
    }
}
