package com.subah.alarm
import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.CalendarContract
import org.json.JSONObject
import java.net.URL
import java.net.URLEncoder
import java.util.*

object Brief {
    private val DAY = arrayOf(
        "Ravivar, Surya Dev ka din. Mantra: ॐ सूर्याय नमः",
        "Somvar, Shiv ji ka din. Mantra: ॐ नमः शिवाय",
        "Mangalvar, Hanuman ji ka din. Mantra: ॐ हनुमते नमः",
        "Budhvar, Ganesh ji ka din. Mantra: ॐ गं गणपतये नमः",
        "Guruvar, Vishnu ji ka din. Mantra: ॐ नमो भगवते वासुदेवाय",
        "Shukravar, Mata Lakshmi ka din. Mantra: ॐ श्रीं महालक्ष्म्यै नमः",
        "Shanivar, Shani Dev ka din. Mantra: ॐ शं शनैश्चराय नमः")

    fun build(c: Context): String {
        val sb = StringBuilder("Shubh prabhat! Aaj ${DAY[Calendar.getInstance().get(Calendar.DAY_OF_WEEK) - 1]}. ")
        sb.append("${Store.streak(c)} din ki streak ho gayi hai. ")
        weather(c)?.let { sb.append(it).append(' ') }
        events(c)?.let { sb.append(it).append(' ') }
        val todo = Store.str(c, "todo"); if (todo.isNotEmpty()) sb.append("Aaj ka pehla kaam: $todo.")
        return sb.toString()
    }

    private fun weather(c: Context): String? = try {
        val city = Store.str(c, "city"); if (city.isEmpty()) null else {
            val g = JSONObject(URL("https://geocoding-api.open-meteo.com/v1/search?count=1&name=" + URLEncoder.encode(city, "UTF-8")).readText()).getJSONArray("results").getJSONObject(0)
            val w = JSONObject(URL("https://api.open-meteo.com/v1/forecast?latitude=${g.getDouble("latitude")}&longitude=${g.getDouble("longitude")}&current=temperature_2m&daily=temperature_2m_max,precipitation_probability_max&timezone=auto&forecast_days=1").readText())
            val d = w.getJSONObject("daily")
            "$city me abhi ${w.getJSONObject("current").getDouble("temperature_2m").toInt()} degree hai, aaj maximum ${d.getJSONArray("temperature_2m_max").getDouble(0).toInt()} degree, baarish ki sambhavna ${d.getJSONArray("precipitation_probability_max").optInt(0)} percent."
        }
    } catch (e: Exception) { null }

    private fun events(c: Context): String? = try {
        if (c.checkSelfPermission(Manifest.permission.READ_CALENDAR) != PackageManager.PERMISSION_GRANTED) null else {
            val now = System.currentTimeMillis()
            val end = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59) }.timeInMillis
            val l = mutableListOf<String>()
            CalendarContract.Instances.query(c.contentResolver, arrayOf("title", "begin"), now, end)?.use {
                while (it.moveToNext() && l.size < 4) l.add("${android.text.format.DateFormat.format("h:mm a", it.getLong(1))} par ${it.getString(0)}")
            }
            if (l.isEmpty()) "Calendar me aaj koi event nahi hai." else "Aaj ke events: " + l.joinToString(", ") + "."
        }
    } catch (e: Exception) { null }
}
