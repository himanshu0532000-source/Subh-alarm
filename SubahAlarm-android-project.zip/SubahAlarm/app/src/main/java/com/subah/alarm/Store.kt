package com.subah.alarm
import android.content.Context
import org.json.*
import java.text.SimpleDateFormat
import java.util.*

data class Step(var msg: String, var after: Int, var photo: Boolean, var check: String)
data class Day(var on: Boolean, var h: Int, var m: Int)

object Store {
    fun p(c: Context) = c.getSharedPreferences("s", 0)
    fun str(c: Context, k: String, d: String = "") = p(c).getString(k, d) ?: d
    fun put(c: Context, k: String, v: String) = p(c).edit().putString(k, v).apply()

    fun steps(c: Context): MutableList<Step> {
        val l = mutableListOf<Step>()
        try {
            val a = JSONArray(str(c, "steps", "[]"))
            for (i in 0 until a.length()) { val o = a.getJSONObject(i); l.add(Step(o.getString("msg"), o.getInt("after"), o.getBoolean("photo"), o.getString("check"))) }
        } catch (e: Exception) {}
        if (l.isEmpty()) {
            l.add(Step("Uth jao! Bathroom jao aur brush karte hue photo kheencho.", 0, true, "a person brushing their teeth, or holding a toothbrush near their mouth"))
            l.add(Step("Ab ready ho jao aur ready hokar photo dikhao.", 15, true, "a person dressed in normal day clothes and ready to go out, not lying in bed"))
        }
        return l
    }
    fun saveSteps(c: Context, l: List<Step>) {
        val a = JSONArray(); l.forEach { a.put(JSONObject().put("msg", it.msg).put("after", it.after).put("photo", it.photo).put("check", it.check)) }
        put(c, "steps", a.toString())
    }
    fun days(c: Context): List<Day> {
        val l = MutableList(7) { Day(true, 6, 0) }
        try { val a = JSONArray(str(c, "days", "[]")); for (i in 0 until minOf(7, a.length())) { val o = a.getJSONObject(i); l[i] = Day(o.getBoolean("on"), o.getInt("h"), o.getInt("m")) } } catch (e: Exception) {}
        return l
    }
    fun saveDays(c: Context, l: List<Day>) {
        val a = JSONArray(); l.forEach { a.put(JSONObject().put("on", it.on).put("h", it.h).put("m", it.m)) }
        put(c, "days", a.toString())
    }
    private val F get() = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    fun hist(c: Context): JSONArray = try { JSONArray(str(c, "hist", "[]")) } catch (e: Exception) { JSONArray() }
    fun addHistory(c: Context, delay: Int, n: Int) {
        val t = F.format(Date()); val out = JSONArray(); val a = hist(c)
        for (i in maxOf(0, a.length() - 120) until a.length()) if (a.getJSONObject(i).getString("d") != t) out.put(a.getJSONObject(i))
        out.put(JSONObject().put("d", t).put("delay", delay).put("n", n)); put(c, "hist", out.toString())
    }
    fun streak(c: Context): Int {
        val a = hist(c); val s = HashSet<String>()
        for (i in 0 until a.length()) s.add(a.getJSONObject(i).getString("d"))
        val cal = Calendar.getInstance()
        if (!s.contains(F.format(cal.time))) cal.add(Calendar.DAY_OF_YEAR, -1)
        var n = 0
        while (s.contains(F.format(cal.time))) { n++; cal.add(Calendar.DAY_OF_YEAR, -1) }
        return n
    }
}
