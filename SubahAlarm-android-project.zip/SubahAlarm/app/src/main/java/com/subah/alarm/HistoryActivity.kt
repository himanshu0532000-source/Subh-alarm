package com.subah.alarm
import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

class HistoryActivity : AppCompatActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val a = Store.hist(this)
        val cut = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(System.currentTimeMillis() - 6L * 86400000))
        var n = 0; var sum = 0; var worst = -1; var worstD = ""
        val lines = StringBuilder()
        for (i in a.length() - 1 downTo maxOf(0, a.length() - 14)) { val o = a.getJSONObject(i); lines.append("✅ ${o.getString("d")}  — ${o.getInt("delay")} min me photo\n") }
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            if (o.getString("d") >= cut) { n++; sum += o.getInt("delay"); if (o.getInt("delay") > worst) { worst = o.getInt("delay"); worstD = o.getString("d") } }
        }
        val report = "🔥 Streak: ${Store.streak(this)} din\n\n📊 Is hafte: $n/7 din routine poora\n" +
            (if (n > 0) "Photo me average ${sum / n} min lage\nSabse late: $worstD ($worst min)\n" else "") + "\nPichhle din:\n$lines"
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 60, 40, 40) }
        l.addView(TextView(this).apply { text = report; textSize = 16f })
        l.addView(Button(this).apply { text = "📤 Report share karo"; setOnClickListener { startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, report), "Share")) } })
        val row = LinearLayout(this)
        getExternalFilesDir(null)?.listFiles { f -> f.extension == "jpg" }?.sortedByDescending { it.lastModified() }?.take(12)?.forEach { f ->
            row.addView(ImageView(this).apply {
                setImageBitmap(BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = 4 })); setPadding(0, 0, 12, 0); adjustViewBounds = true
                layoutParams = LinearLayout.LayoutParams(300, 400)
            })
        }
        l.addView(TextView(this).apply { text = "\n📸 Photos (collage)"; textSize = 16f })
        l.addView(HorizontalScrollView(this).apply { addView(row) })
        setContentView(ScrollView(this).apply { addView(l) })
    }
}
