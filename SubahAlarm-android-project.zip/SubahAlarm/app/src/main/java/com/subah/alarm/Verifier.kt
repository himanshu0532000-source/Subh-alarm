package com.subah.alarm
import android.util.Base64
import org.json.*
import java.net.HttpURLConnection
import java.net.URL

object Verifier {
    /** null = photo theek hai (ya check nahi ho paya); warna reject karne ki wajah. */
    fun check(key: String, what: String, jpg: ByteArray): String? = try {
        val img = JSONObject().put("type", "image").put("source", JSONObject().put("type", "base64").put("media_type", "image/jpeg").put("data", Base64.encodeToString(jpg, Base64.NO_WRAP)))
        val txt = JSONObject().put("type", "text").put("text", "Does this photo show: $what? Be reasonably lenient about angle and lighting, but reject blank walls, ceilings, floors, covered camera, or photos of photos. Reply exactly 'YES' or 'NO: <max 6 words reason in Hinglish>'.")
        val body = JSONObject().put("model", "claude-haiku-5-5").put("max_tokens", 40)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", JSONArray().put(img).put(txt))))
        val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 25000
        c.setRequestProperty("x-api-key", key); c.setRequestProperty("anthropic-version", "2023-06-01"); c.setRequestProperty("content-type", "application/json")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        if (c.responseCode != 200) null else {
            val t = JSONObject(c.inputStream.bufferedReader().readText()).getJSONArray("content").getJSONObject(0).getString("text").trim()
            if (t.startsWith("YES", true)) null else t.removePrefix("NO:").trim().ifEmpty { "Photo saaf nahi hai" }
        }
    } catch (e: Exception) { null }
}
