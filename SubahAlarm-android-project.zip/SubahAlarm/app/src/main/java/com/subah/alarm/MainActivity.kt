package com.subah.alarm
import android.Manifest
import android.app.TimePickerDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import java.util.Date

class MainActivity : AppCompatActivity() {
    private lateinit var steps: MutableList<Step>
    private lateinit var box: LinearLayout

    private fun tv(t: String, big: Boolean = false) = TextView(this).apply { text = t; if (big) { textSize = 18f; setPadding(0, 36, 0, 8) } }
    private fun et(hint: String, v: String, num: Boolean = false, on: (String) -> Unit) = EditText(this).apply {
        this.hint = hint; setText(v); if (num) inputType = InputType.TYPE_CLASS_NUMBER
        addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { on(s.toString()) }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
    }
    private fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
    private fun pref(hint: String, k: String, num: Boolean = false) = et(hint, Store.str(this, k), num) { Store.put(this, k, it.trim()) }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA, Manifest.permission.POST_NOTIFICATIONS, Manifest.permission.SEND_SMS, Manifest.permission.READ_CALENDAR), 1)
        steps = Store.steps(this)
        val days = Store.days(this)
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 60, 40, 60) }
        l.addView(tv("⏰ Subah Alarm", true))
        l.addView(tv("Din aur time", true))
        listOf("Ravivar", "Somvar", "Mangalvar", "Budhvar", "Guruvar", "Shukravar", "Shanivar").forEachIndexed { i, n ->
            val d = days[i]
            val tb = Button(this)
            fun lbl() { tb.text = "%02d:%02d".format(d.h, d.m) }; lbl()
            tb.setOnClickListener { TimePickerDialog(this, { _, hh, mm -> d.h = hh; d.m = mm; lbl() }, d.h, d.m, true).show() }
            val row = LinearLayout(this)
            row.addView(CheckBox(this).apply { text = n; isChecked = d.on; setOnCheckedChangeListener { _, v -> d.on = v } }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(tb); l.addView(row)
        }
        l.addView(tv("Routine ke steps", true))
        box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; l.addView(box); renderSteps()
        l.addView(btn("+ Step jodo") { steps.add(Step("Agla kaam karke photo kheencho.", 15, true, "the person doing the task")); renderSteps() })

        l.addView(tv("Bhajan (YouTube)", true))
        l.addView(CheckBox(this).apply { text = "Bhajan bajao"; isChecked = Store.str(this@MainActivity, "bhajan", "1") == "1"; setOnCheckedChangeListener { _, v -> Store.put(this@MainActivity, "bhajan", if (v) "1" else "0") } })
        l.addView(pref("YouTube Data API key", "ytkey"))
        l.addView(pref("Kya search kare (jaise: new bhajan)", "q"))
        l.addView(pref("Channel ID (optional, jaise sirf ek channel)", "channel"))

        l.addView(tv("AI photo check", true))
        l.addView(pref("Anthropic (Claude) API key", "akey"))

        l.addView(tv("Late hone par SMS", true))
        l.addView(pref("Kisko SMS jaye (phone number)", "phone"))
        l.addView(pref("Kitne min late ke baad (default 30)", "late", true))

        l.addView(tv("Subah ka brief", true))
        l.addView(pref("Shehar (mausam ke liye)", "city"))
        l.addView(pref("Aaj ka pehla kaam", "todo"))

        l.addView(btn("✅ Alarm set karo") {
            Store.saveSteps(this, steps); Store.saveDays(this, days)
            val t = Scheduler.scheduleNext(this)
            Toast.makeText(this, if (t < 0) "Koi din on nahi hai" else "Agla alarm: ${Date(t)}", Toast.LENGTH_LONG).show()
        })
        l.addView(btn("🧪 Test (5 sec, 2nd step 1 min baad)") {
            Store.saveSteps(this, steps); Store.saveDays(this, days)
            Store.p(this).edit().putBoolean("test", true).apply(); Scheduler.setStep(this, 0, System.currentTimeMillis() + 5000)
            Toast.makeText(this, "5 sec me baje ga", Toast.LENGTH_SHORT).show()
        })
        l.addView(btn("📊 Streak aur history") { startActivity(Intent(this, HistoryActivity::class.java)) })
        l.addView(btn("🔋 Battery optimization hatao (zaroori)") {
            try { startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))) } catch (e: Exception) {}
        })
        l.addView(btn("📱 Full-screen alarm permission (Android 14)") {
            try { startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:$packageName"))) } catch (e: Exception) {}
        })
        setContentView(ScrollView(this).apply { addView(l) })
    }

    private fun renderSteps() {
        box.removeAllViews()
        steps.forEachIndexed { i, s ->
            box.addView(tv("Step ${i + 1}", true))
            box.addView(et("Voice me kya bole", s.msg) { s.msg = it })
            if (i > 0) box.addView(et("Pichhle step ke kitne min baad", s.after.toString(), true) { s.after = it.toIntOrNull() ?: 1 })
            box.addView(CheckBox(this).apply { text = "Photo zaroori"; isChecked = s.photo; setOnCheckedChangeListener { _, v -> s.photo = v } })
            box.addView(et("AI kya check kare (English me)", s.check) { s.check = it })
            if (steps.size > 1) box.addView(btn("Hatao") { steps.removeAt(i); steps[0].after = 0; renderSteps() })
        }
    }
}
