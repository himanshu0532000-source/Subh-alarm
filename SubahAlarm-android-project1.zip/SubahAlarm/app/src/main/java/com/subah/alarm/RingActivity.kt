package com.subah.alarm
import android.Manifest
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.*
import android.media.AudioManager
import android.media.ExifInterface
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.*
import android.speech.tts.TextToSpeech
import android.telephony.SmsManager
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.*

class RingActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    private var step = 0
    private lateinit var steps: List<Step>
    private lateinit var tts: TextToSpeech
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var vib: Vibrator
    private lateinit var am: AudioManager
    private var web: WebView? = null
    private var cap: ImageCapture? = null
    private var provider: ProcessCameraProvider? = null
    private var ring: Ringtone? = null
    private val h = Handler(Looper.getMainLooper())
    private var missed = 0; private var vol = 0.4f
    private var playing = false; private var busy = false; private var ttsReady = false
    private val startMs = System.currentTimeMillis()

    private val speaker = object : Runnable {
        override fun run() {
            if (!ttsReady) return
            val s = steps[step].msg
            tts.speak(if (missed == 0) s else "$s ${missed * 2} minute ho gaye, jaldi karo!", TextToSpeech.QUEUE_FLUSH, null, "m")
            h.postDelayed(this, 9000)
        }
    }
    private val escalate = object : Runnable {   // har 2 min me aur zor se
        override fun run() { missed++; vib.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 900, 100), 0)); h.postDelayed(this, 120000) }
    }
    private val ramp = object : Runnable {      // awaaz dheere se badhti hai
        override fun run() { vol = minOf(1f, vol + 0.1f); setVol(); if (vol < 1f) h.postDelayed(this, 6000) }
    }
    private fun setVol() { am.setStreamVolume(AudioManager.STREAM_MUSIC, (am.getStreamMaxVolume(AudioManager.STREAM_MUSIC) * vol).toInt(), 0) }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        @Suppress("DEPRECATION")
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) { override fun handleOnBackPressed() {} })
        steps = Store.steps(this); step = intent.getIntExtra("step", 0).coerceIn(0, steps.size - 1)
        am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        vib = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        val dp = resources.displayMetrics.density
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(30, 60, 30, 30); setBackgroundColor(0xFF1D2433.toInt()) }
        val tv = TextView(this).apply { text = steps[step].msg; textSize = 22f; setTextColor(0xFFFFF6E5.toInt()) }
        status = TextView(this).apply { setTextColor(0xFFFFB629.toInt()); textSize = 16f }
        root.addView(tv); root.addView(status)
        val needPhoto = steps[step].photo
        if (needPhoto) { val pv = PreviewView(this); root.addView(pv, LinearLayout.LayoutParams(-1, 0, 1f)); startCamera(pv) }
        else root.addView(View(this), LinearLayout.LayoutParams(-1, 0, 1f))
        val key = Store.str(this, "ytkey")
        if (Store.str(this, "bhajan", "1") == "1" && key.isNotEmpty()) {
            val wv = WebView(this); web = wv; root.addView(wv, LinearLayout.LayoutParams(-1, (200 * dp).toInt())); startBhajan(key)
        } else fallback()
        val btn = Button(this).apply { text = if (needPhoto) "📸 Photo kheencho" else "✅ Ho gaya"; setOnClickListener { if (needPhoto) snap() else accepted() } }
        root.addView(btn); setContentView(root)

        tts = TextToSpeech(this, this)
        vib.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 600, 400), 0))
        setVol(); h.postDelayed(ramp, 6000); h.postDelayed(escalate, 120000)
        val late = Store.str(this, "late", "30").toIntOrNull() ?: 30
        h.postDelayed({ sendLate(late) }, late * 60000L)
    }

    override fun onInit(s: Int) { tts.language = Locale("hi", "IN"); ttsReady = true; h.post(speaker) }

    private fun startCamera(pv: PreviewView) {
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            provider = f.get(); val prev = Preview.Builder().build().also { it.setSurfaceProvider(pv.surfaceProvider) }
            val ic = ImageCapture.Builder().build(); cap = ic; val pr = f.get(); provider = pr; pr.unbindAll()
            pr.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, prev, ic)
        }, ContextCompat.getMainExecutor(this))
    }

    inner class JS {
        @JavascriptInterface fun ok() { playing = true }
        @JavascriptInterface fun err() { h.post { fallback() } }
    }

    private fun startBhajan(key: String) {
        val q = Store.str(this, "q", "new bhajan"); val ch = Store.str(this, "channel")
        Thread {
            try {
                val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
                var u = "https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&videoEmbeddable=true&order=date&maxResults=15&q=" + URLEncoder.encode(q, "UTF-8") +
                    "&publishedAfter=" + sdf.format(Date(System.currentTimeMillis() - 7L * 86400000)) + "&key=" + key
                if (ch.isNotEmpty()) u += "&channelId=$ch"
                val items = JSONObject(URL(u).readText()).getJSONArray("items")
                val id = items.getJSONObject(Random().nextInt(items.length())).getJSONObject("id").getString("videoId")
                val html = "<html><body style='margin:0;background:#000'><div id=p></div><script src='https://www.youtube.com/iframe_api'></script><script>" +
                    "function onYouTubeIframeAPIReady(){new YT.Player('p',{height:'200',width:'200',videoId:'$id',playerVars:{autoplay:1,loop:1,playlist:'$id'}," +
                    "events:{onReady:function(e){e.target.playVideo()},onError:function(){A.err()},onStateChange:function(e){if(e.data==1)A.ok()}}})}</script></body></html>"
                runOnUiThread {
                    web?.settings?.javaScriptEnabled = true; web?.settings?.mediaPlaybackRequiresUserGesture = false
                    web?.addJavascriptInterface(JS(), "A")
                    web?.loadDataWithBaseURL("https://www.youtube.com", html, "text/html", "utf-8", null)
                    h.postDelayed({ if (!playing) fallback() }, 20000)  // 20 sec me bhajan nahi chala to alarm tone
                }
            } catch (e: Exception) { runOnUiThread { fallback() } }
        }.start()
    }

    private fun fallback() {
        if (ring != null) return
        ring = RingtoneManager.getRingtone(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
        ring?.isLooping = true; ring?.play()
    }

    private fun snap() {
        if (busy) return; busy = true; status.text = "Photo check ho rahi hai…"
        val f = File(getExternalFilesDir(null), "s${step + 1}_${System.currentTimeMillis()}.jpg")
        cap?.takePicture(ImageCapture.OutputFileOptions.Builder(f).build(), ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(o: ImageCapture.OutputFileResults) { verify(f) }
            override fun onError(e: ImageCaptureException) { busy = false; status.text = "Photo nahi aayi, dobara try karo" }
        }) ?: run { busy = false; status.text = "Camera allow karo" }
    }

    private fun verify(f: File) {
        Thread {
            var reason: String? = null
            try {
                var bmp = BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = 2 })
                val deg = when (ExifInterface(f.path).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) { 6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f }
                if (deg != 0f) bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(deg) }, true)
                val t = Bitmap.createScaledBitmap(bmp, 16, 16, true); var sum = 0.0
                for (x in 0 until 16) for (y in 0 until 16) { val p = t.getPixel(x, y); sum += 0.299 * Color.red(p) + 0.587 * Color.green(p) + 0.114 * Color.blue(p) }
                if (sum / 256 < 30) reason = "Bahut andhera hai, roshni me photo lo"
                else {
                    val key = Store.str(this, "akey")
                    if (key.isNotEmpty()) {
                        val sc = minOf(1f, 768f / maxOf(bmp.width, bmp.height))
                        val s = Bitmap.createScaledBitmap(bmp, (bmp.width * sc).toInt(), (bmp.height * sc).toInt(), true)
                        val out = ByteArrayOutputStream(); s.compress(Bitmap.CompressFormat.JPEG, 75, out)
                        reason = Verifier.check(key, steps[step].check, out.toByteArray())
                    }
                }
            } catch (e: Exception) {}
            runOnUiThread { busy = false; if (reason != null) { f.delete(); status.text = "❌ $reason" } else accepted() }
        }.start()
    }

    private fun stopAll() {
        h.removeCallbacksAndMessages(null); try { tts.stop() } catch (e: Exception) {}
        ring?.stop(); vib.cancel(); provider?.unbindAll()
        web?.let { (it.parent as? ViewGroup)?.removeView(it); it.destroy() }; web = null
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(1)
    }

    private fun accepted() {
        stopAll()
        if (step == 0) Store.p(this).edit().putInt("d0", ((System.currentTimeMillis() - startMs) / 60000).toInt()).apply()
        if (step + 1 < steps.size) {
            val gap = if (Store.p(this).getBoolean("test", false)) 1 else steps[step + 1].after
            Scheduler.setStep(this, step + 1, System.currentTimeMillis() + gap * 60000L)
            finish()
        } else {
            Store.addHistory(this, Store.p(this).getInt("d0", 0), steps.size)
            Store.p(this).edit().putBoolean("test", false).apply()
            showBrief()
        }
    }

    private fun showBrief() {
        root.removeAllViews()
        val tv = TextView(this).apply { text = "Aaj ka brief load ho raha hai…"; textSize = 20f; setTextColor(0xFFFFF6E5.toInt()) }
        root.addView(ScrollView(this).apply { addView(tv) }, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(Button(this).apply { text = "✅ Din shuru!"; setOnClickListener { finish() } })
        Thread {
            val t = Brief.build(this)
            runOnUiThread { tv.text = t; if (ttsReady) tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "b") }
        }.start()
    }

    private fun sendLate(min: Int) {
        val num = Store.str(this, "phone"); if (num.isEmpty()) return
        if (checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) return
        try {
            @Suppress("DEPRECATION")
            SmsManager.getDefault().sendTextMessage(num, null, "Subah Alarm: main abhi tak uth kar step ${step + 1} poora nahi kar paya, $min minute late ho gaya!", null, null)
        } catch (e: Exception) {}
    }

    override fun onDestroy() { h.removeCallbacksAndMessages(null); try { tts.shutdown() } catch (e: Exception) {}; super.onDestroy() }
}
